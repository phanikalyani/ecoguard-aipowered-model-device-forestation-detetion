# EcoGuard backend (Flask + FCM) - server.py
import os, json, time, sqlite3
from datetime import datetime
from flask import Flask, request, jsonify, g
import firebase_admin
from firebase_admin import credentials, messaging

DB_PATH = os.environ.get("DB_PATH", "alerts.db")
FCM_TOPIC = os.environ.get("FCM_TOPIC", "rangers")
GOOGLE_APPLICATION_CREDENTIALS = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", "/secrets/serviceAccountKey.json")

app = Flask(__name__)

def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DB_PATH)
        db.row_factory = sqlite3.Row
    return db

def init_db():
    db = get_db()
    db.execute("""
    CREATE TABLE IF NOT EXISTS alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      device_id TEXT,
      label TEXT,
      confidence REAL,
      timestamp INTEGER,
      gps_lat REAL,
      gps_lon REAL,
      payload TEXT,
      received_at TEXT
    )""")
    db.commit()

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

FIREBASE_INITED = False
def init_firebase():
    global FIREBASE_INITED
    if FIREBASE_INITED:
        return
    cred_path = GOOGLE_APPLICATION_CREDENTIALS
    if cred_path and os.path.exists(cred_path):
        cred = credentials.Certificate(cred_path)
        firebase_admin.initialize_app(cred)
        FIREBASE_INITED = True
        app.logger.info("Firebase initialized")
    else:
        app.logger.warning("Firebase service account not found; FCM disabled.")

@app.route("/api/alerts", methods=["POST"])
def receive_alert():
    data = request.get_json(force=True)
    if not data:
        return jsonify({"error": "Invalid JSON"}), 400

    device_id = data.get("device_id")
    label = data.get("label")
    confidence = float(data.get("confidence", data.get("score", 0)))
    timestamp = int(data.get("timestamp", int(time.time())))
    gps = data.get("gps", {}) or {}
    lat = gps.get("lat") or gps.get("latitude") or (gps[0] if isinstance(gps, list) and len(gps)>0 else None)
    lon = gps.get("lon") or gps.get("longitude") or (gps[1] if isinstance(gps, list) and len(gps)>1 else None)

    received_at = datetime.utcnow().isoformat()
    payload_str = json.dumps(data)

    db = get_db()
    cur = db.cursor()
    cur.execute(
        "INSERT INTO alerts (device_id,label,confidence,timestamp,gps_lat,gps_lon,payload,received_at) VALUES (?,?,?,?,?,?,?,?)",
        (device_id, label, confidence, timestamp, lat, lon, payload_str, received_at)
    )
    db.commit()
    alert_id = cur.lastrowid

    init_firebase()
    if FIREBASE_INITED:
        try:
            send_push_notification(alert_id, device_id, label, confidence)
        except Exception as e:
            app.logger.error("FCM send failed: %s", e)

    return jsonify({"status": "ok", "id": alert_id}), 200

@app.route("/api/alerts", methods=["GET"])
def list_alerts():
    db = get_db()
    cur = db.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 200")
    rows = cur.fetchall()
    out = []
    for r in rows:
        payload = json.loads(r["payload"]) if r["payload"] else {}
        out.append({
            "id": r["id"],
            "device_id": r["device_id"],
            "label": r["label"],
            "confidence": r["confidence"],
            "timestamp": r["timestamp"],
            "gps": {"lat": r["gps_lat"], "lon": r["gps_lon"]} if r["gps_lat"] and r["gps_lon"] else None,
            "received_at": r["received_at"],
            "payload": payload
        })
    return jsonify(out), 200

@app.route("/api/subscribe_token", methods=["POST"])
def subscribe_token():
    data = request.get_json(force=True)
    token = data.get("token")
    if not token:
        return jsonify({"error": "token required"}), 400
    init_firebase()
    if not FIREBASE_INITED:
        return jsonify({"error": "firebase not configured"}), 500
    resp = messaging.subscribe_to_topic([token], FCM_TOPIC)
    return jsonify({"success": True, "resp": resp.__dict__}), 200

def send_push_notification(alert_id, device_id, label, confidence):
    title = f"EcoGuard: {label or 'Alert'}"
    body = f"Device {device_id or 'unknown'} · {confidence:.2f}"
    data_payload = {"alert_id": str(alert_id), "label": str(label or ""), "confidence": str(confidence)}
    message = messaging.Message(
        notification=messaging.Notification(title=title, body=body),
        data=data_payload,
        topic=FCM_TOPIC
    )
    res = messaging.send(message)
    app.logger.info("FCM sent: %s", res)
    return res

if __name__ == "__main__":
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    init_db()
    init_firebase()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=os.environ.get("FLASK_DEBUG","false").lower() in ("1","true"))

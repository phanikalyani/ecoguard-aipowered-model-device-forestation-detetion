EcoGuard Backend
----------------
Flask-based backend that receives alerts from edge devices and forwards push notifications via Firebase Cloud Messaging.
See server.py for implementation.

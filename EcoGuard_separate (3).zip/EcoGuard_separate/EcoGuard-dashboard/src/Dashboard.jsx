import React, { useEffect, useState } from "react";

export default function Dashboard(){
  const API = import.meta.env.VITE_API_URL || "/api";
  const [alerts, setAlerts] = useState([]);
  useEffect(()=>{
    async function fetchAlerts(){
      try {
        const res = await fetch(`${API}/alerts`);
        const data = await res.json();
        setAlerts(data);
      } catch(e){
        console.error(e);
      }
    }
    fetchAlerts();
    const t = setInterval(fetchAlerts, 5000);
    return ()=> clearInterval(t);
  },[]);
  return (
    <div style={{background:'#0f172a', color:'#e6eef8', minHeight:'100vh', padding:20}}>
      <h1>EcoGuard Dashboard</h1>
      <p>Recent alerts (latest first)</p>
      <ul>
        {alerts.map(a=>(
          <li key={a.id}>{a.id} - {a.label} - {a.device_id} - {a.confidence}</li>
        ))}
      </ul>
    </div>
  )
}

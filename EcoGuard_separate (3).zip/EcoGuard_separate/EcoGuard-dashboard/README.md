EcoGuard Dashboard
------------------
Simple Vite React dashboard. Run `npm install` and `npm run dev` for development.

EcoGuard Mobile (Flutter)
-------------------------
This is a skeleton showing how to integrate Firebase Messaging. Replace Firebase config per platform and run `flutter pub get` then `flutter run`.

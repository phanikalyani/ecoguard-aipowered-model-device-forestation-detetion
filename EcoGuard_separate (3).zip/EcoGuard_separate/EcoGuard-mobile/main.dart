import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  print('Background message: ${message.messageId}');
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  runApp(MyApp());
}

class MyApp extends StatefulWidget { @override State<MyApp> createState() => _MyAppState(); }

class _MyAppState extends State<MyApp> {
  String? _token;
  @override
  void initState(){
    super.initState();
    _initFCM();
    FirebaseMessaging.onMessage.listen((RemoteMessage message){
      print('Message: ${message.notification?.title} - ${message.notification?.body}');
      // show dialog or local notification
    });
  }

  Future<void> _initFCM() async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;
    NotificationSettings settings = await messaging.requestPermission();
    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      String? token = await messaging.getToken();
      setState(() => _token = token);
      print('FCM Token: $token');
      // send token to backend to subscribe to topic
      try {
        final resp = await http.post(Uri.parse('http://10.0.2.2:5000/api/subscribe_token'),
          headers: {'Content-Type':'application/json'},
          body: jsonEncode({'token': token}));
        print('subscribe resp: ${resp.statusCode} ${resp.body}');
      } catch(e){
        print('subscribe error: $e');
      }
    } else {
      print('FCM permission not granted');
    }
  }

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      title: 'EcoGuard Mobile',
      home: Scaffold(
        appBar: AppBar(title: Text('EcoGuard')),
        body: Center(child: Text('FCM token: ${_token ?? "loading..."}')),
      ),
    );
  }
}
